import express from "express";
import { createServer as createViteServer } from "vite";
import fs from "fs";
import path from "path";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.get("/api/search", (req, res) => {
    try {
      const seedDataPath = path.resolve(process.cwd(), "seed/seed-properties.json");
      const seedData = JSON.parse(fs.readFileSync(seedDataPath, "utf-8"));
      
      const { status, type, district, priceMin, priceMax, beds, q } = req.query;
      
      let results = seedData;

      if (status) results = results.filter((p: any) => p.status === status);
      if (type) results = results.filter((p: any) => p.type === type);
      if (district) results = results.filter((p: any) => p.location.district.toLowerCase() === (district as string).toLowerCase());
      if (priceMin) results = results.filter((p: any) => p.price && p.price >= Number(priceMin));
      if (priceMax) results = results.filter((p: any) => p.price && p.price <= Number(priceMax));
      if (beds) results = results.filter((p: any) => p.bedrooms >= Number(beds));
      if (q) {
        const query = (q as string).toLowerCase();
        results = results.filter((p: any) => 
          p.title.toLowerCase().includes(query) || 
          p.location.neighborhood.toLowerCase().includes(query) ||
          p.code.toLowerCase().includes(query)
        );
      }

      res.json(results);
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/listing/:code", (req, res) => {
    try {
      const seedDataPath = path.resolve(process.cwd(), "seed/seed-properties.json");
      const seedData = JSON.parse(fs.readFileSync(seedDataPath, "utf-8"));
      const listing = seedData.find((p: any) => p.code === req.params.code);
      
      if (listing) {
        res.json(listing);
      } else {
        res.status(404).json({ error: "Listing not found" });
      }
    } catch (error) {
      console.error("Listing fetch error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/leads", (req, res) => {
    const { name, email, phone, propertyCode, goal, budget } = req.body;
    
    if (!name || !email || !phone) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    // In a real app, save to DB. Here we just log it.
    console.log("New Lead:", { name, email, phone, propertyCode, goal, budget });
    
    res.status(200).json({ success: true, message: "Lead captured successfully" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.resolve(process.cwd(), "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve(process.cwd(), "dist/index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
