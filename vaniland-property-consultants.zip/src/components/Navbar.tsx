import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-deep-navy/90 backdrop-blur-xl text-white sticky top-0 z-50 border-b border-white/5 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-24">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center gap-2">
              <span className="font-montserrat text-2xl tracking-[0.3em] font-light">VANILAND</span>
            </Link>
          </div>
          <div className="hidden md:flex items-center space-x-10">
            <Link to="/listings" className="text-xs uppercase tracking-[0.2em] text-white/80 hover:text-gold transition-colors duration-300">Properties</Link>
            <Link to="/contact" className="text-xs uppercase tracking-[0.2em] text-white/80 hover:text-gold transition-colors duration-300">Contact Us</Link>
          </div>
          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-white hover:text-gold transition-colors duration-300">
              {isOpen ? <X size={24} strokeWidth={1.5} /> : <Menu size={24} strokeWidth={1.5} />}
            </button>
          </div>
        </div>
      </div>
      {isOpen && (
        <div className="md:hidden bg-deep-navy/95 backdrop-blur-xl border-t border-white/5">
          <div className="px-4 pt-4 pb-6 space-y-4">
            <Link to="/listings" className="block text-xs uppercase tracking-[0.2em] text-white/80 hover:text-gold transition-colors duration-300">Properties</Link>
            <Link to="/contact" className="block text-xs uppercase tracking-[0.2em] text-white/80 hover:text-gold transition-colors duration-300">Contact Us</Link>
          </div>
        </div>
      )}
    </nav>
  );
}
