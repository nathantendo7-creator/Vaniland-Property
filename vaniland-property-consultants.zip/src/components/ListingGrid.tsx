import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import ListingCard from './ListingCard';

gsap.registerPlugin(ScrollTrigger);

interface ListingGridProps {
  listings: any[];
  title?: string;
  subtitle?: string;
}

export default function ListingGrid({ listings, title = "Featured Properties", subtitle = "Explore our handpicked selection of premium real estate." }: ListingGridProps) {
  const gridRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(headerRef.current, 
        { y: 30, opacity: 0 }, 
        { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', scrollTrigger: { trigger: headerRef.current, start: 'top 80%' } }
      );

      const cards = gsap.utils.toArray('.listing-card-wrapper');
      gsap.fromTo(cards, 
        { y: 50, opacity: 0 }, 
        { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: gridRef.current, start: 'top 75%' } }
      );
    }, gridRef);

    return () => ctx.revert();
  }, [listings]);

  return (
    <section className="py-20 bg-slate-50" ref={gridRef}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={headerRef} className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-montserrat font-light text-deep-navy uppercase tracking-widest mb-4">{title}</h2>
          <p className="text-slate-500 max-w-2xl mx-auto">{subtitle}</p>
          <div className="w-24 h-1 bg-gold mx-auto mt-8 rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {listings.map((listing) => (
            <div key={listing.code} className="listing-card-wrapper">
              <ListingCard listing={listing} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
