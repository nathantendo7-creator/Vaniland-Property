import { Link } from 'react-router-dom';
import { MapPin, Bed, Bath } from 'lucide-react';

interface ListingProps {
  listing: {
    code: string;
    title: string;
    type: string;
    status: string;
    price: number | null;
    currency: string;
    bedrooms: number;
    bathrooms: number;
    location: { district: string; neighborhood: string };
    premium?: boolean;
  };
}

export default function ListingCard({ listing }: ListingProps) {
  const formattedPrice = listing.price
    ? new Intl.NumberFormat('en-UG', { style: 'currency', currency: listing.currency }).format(listing.price)
    : 'Contact for valuation';

  return (
    <div className="bg-transparent rounded-sm transition-all duration-500 overflow-hidden group flex flex-col h-full border border-slate-200/60 hover:border-gold/50">
      <div className="relative h-[300px] overflow-hidden bg-slate-100 rounded-t-sm">
        <img
          src={`https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80`}
          alt={listing.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 ease-out"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-4 left-4 flex gap-2">
          <span className="bg-deep-navy/40 backdrop-blur-md border border-white/40 text-white text-[10px] font-light px-3 py-1 rounded-full uppercase tracking-[0.15em]">
            {listing.status.replace('-', ' ')}
          </span>
          {listing.premium && (
            <span className="bg-gold/40 backdrop-blur-md border border-white/40 text-white text-[10px] font-light px-3 py-1 rounded-full uppercase tracking-[0.15em]">
              Premium
            </span>
          )}
        </div>
      </div>
      
      <div className="p-8 flex flex-col flex-grow bg-white">
        <div className="flex justify-between items-start mb-3">
          <p className="text-[10px] text-gold font-medium uppercase tracking-[0.2em]">{listing.location.neighborhood}, {listing.location.district}</p>
          <span className="text-[10px] text-slate-400 font-mono tracking-widest">#{listing.code}</span>
        </div>
        
        <h3 className="text-2xl font-cormorant font-medium text-deep-navy mb-5 line-clamp-2 leading-tight">{listing.title}</h3>
        
        <div className="flex items-center gap-6 text-xs text-slate-500 mb-8 font-light tracking-wide">
          <div className="flex items-center gap-2">
            <Bed size={14} className="text-gold/80" strokeWidth={1.5} />
            <span>{listing.bedrooms} Beds</span>
          </div>
          <div className="flex items-center gap-2">
            <Bath size={14} className="text-gold/80" strokeWidth={1.5} />
            <span>{listing.bathrooms} Baths</span>
          </div>
        </div>
        
        <div className="mt-auto pt-5 border-t border-slate-100 flex items-center justify-between">
          <div>
            <p className="text-[9px] text-slate-400 uppercase tracking-[0.2em] mb-1">Asking Price</p>
            <p className="text-lg font-light text-deep-navy tracking-wide">{formattedPrice}</p>
          </div>
          <Link
            to={`/listing/${listing.code}`}
            className="text-deep-navy hover:text-gold text-[10px] font-medium uppercase tracking-[0.2em] transition-colors duration-300 flex items-center gap-1"
          >
            Explore <span className="text-gold">&rarr;</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
