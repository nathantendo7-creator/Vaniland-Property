import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import gsap from 'gsap';

export default function Hero() {
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const btnsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

    tl.fromTo(titleRef.current, { y: 50, opacity: 0 }, { y: 0, opacity: 1, duration: 1, delay: 0.2 })
      .fromTo(subtitleRef.current, { y: 30, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8 }, "-=0.5")
      .fromTo(btnsRef.current, { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8 }, "-=0.4");
  }, []);

  return (
    <div className="relative h-[85vh] min-h-[600px] flex items-center justify-center overflow-hidden bg-deep-navy">
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=2075&q=80"
          alt="Luxury Real Estate"
          className="w-full h-full object-cover opacity-60"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-deep-navy/50 via-deep-navy/20 to-deep-navy" />
      </div>

      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto mt-12">
        <h1 ref={titleRef} className="text-5xl md:text-7xl lg:text-8xl font-montserrat font-extralight text-white tracking-[0.15em] uppercase mb-8 drop-shadow-2xl">
          Defining the Skyline
        </h1>
        <p ref={subtitleRef} className="text-xl md:text-2xl text-gold/90 mb-12 max-w-3xl mx-auto font-cormorant italic font-light leading-relaxed drop-shadow-lg">
          Award-winning residential and commercial developments in Uganda's highest growth cities. From off-plan opportunities to proven income generators.
        </p>
        <div ref={btnsRef} className="flex flex-col sm:flex-row gap-6 justify-center items-center">
          <Link to="/listings" className="bg-transparent border border-gold text-gold hover:bg-gold hover:text-white px-10 py-4 rounded-full uppercase tracking-[0.2em] text-xs font-medium transition-all duration-300 whitespace-nowrap">
            View Current Projects
          </Link>
          <Link to="/contact" className="bg-transparent border border-white/50 text-white hover:bg-white hover:text-deep-navy px-10 py-4 rounded-full uppercase tracking-[0.2em] text-xs font-medium transition-all duration-300 whitespace-nowrap">
            Contact Us
          </Link>
        </div>
      </div>
    </div>
  );
}
