import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-deep-navy text-white py-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-montserrat text-xl tracking-widest font-light mb-4">VANILAND</h3>
            <p className="text-slate-400 text-sm">
              Real Estate Agents, Dealers, and Brokers.
            </p>
          </div>
          <div>
            <h4 className="font-montserrat uppercase tracking-wider mb-4 text-sm text-gold">Contact</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>Phone: +256-758-589258</li>
              <li>Email: info@VanilandProperty.com</li>
            </ul>
          </div>
          <div>
            <h4 className="font-montserrat uppercase tracking-wider mb-4 text-sm text-gold">Services</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>Furnished/Unfurnished rentals</li>
              <li>Land sales</li>
              <li>Property management</li>
              <li>Office space</li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-white/10 text-center text-sm text-slate-500">
          <p>&copy; {new Date().getFullYear()} Vaniland Property Consultants. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
