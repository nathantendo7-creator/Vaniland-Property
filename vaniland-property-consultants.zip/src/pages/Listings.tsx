import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import ListingCard from '../components/ListingCard';
import MapView from '../components/MapView';
import { Search, Filter, Grid, Map as MapIcon } from 'lucide-react';

export default function Listings() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');

  const status = searchParams.get('status') || '';
  const type = searchParams.get('type') || '';
  const district = searchParams.get('district') || '';
  const q = searchParams.get('q') || '';

  useEffect(() => {
    setLoading(true);
    const query = new URLSearchParams(searchParams).toString();
    fetch(`/api/search?${query}`)
      .then(res => res.json())
      .then(data => {
        setListings(data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Failed to fetch listings:", err);
        setLoading(false);
      });
  }, [searchParams]);

  const handleFilterChange = (key: string, value: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (value) {
      newParams.set(key, value);
    } else {
      newParams.delete(key);
    }
    setSearchParams(newParams);
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12">
          <div className="flex justify-between items-end mb-4">
            <div>
              <h1 className="text-4xl font-montserrat font-light text-deep-navy uppercase tracking-widest mb-4">Properties</h1>
              <div className="w-24 h-1 bg-gold rounded-full"></div>
            </div>
            
            <div className="flex bg-white rounded-lg p-1 border border-slate-200 shadow-sm">
              <button
                onClick={() => setViewMode('grid')}
                className={`flex items-center gap-2 px-4 py-2 rounded-md transition-all text-sm font-medium ${viewMode === 'grid' ? 'bg-deep-navy text-white shadow-md' : 'text-slate-500 hover:text-deep-navy'}`}
              >
                <Grid size={16} /> Grid
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={`flex items-center gap-2 px-4 py-2 rounded-md transition-all text-sm font-medium ${viewMode === 'map' ? 'bg-deep-navy text-white shadow-md' : 'text-slate-500 hover:text-deep-navy'}`}
              >
                <MapIcon size={16} /> Map
              </button>
            </div>
          </div>

          <div className="bg-white/80 backdrop-blur-md p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-4 items-center mt-8">
            <div className="relative flex-grow w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
              <input
                type="text"
                placeholder="Search by title, code, or neighborhood..."
                className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-gold/50 focus:border-gold transition-all bg-white/50 backdrop-blur-sm"
                value={q}
                onChange={(e) => handleFilterChange('q', e.target.value)}
              />
            </div>
            
            <div className="flex gap-4 w-full md:w-auto">
              <select
                className="w-full md:w-48 px-4 py-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-gold/50 focus:border-gold transition-all bg-white/50 backdrop-blur-sm"
                value={status}
                onChange={(e) => handleFilterChange('status', e.target.value)}
              >
                <option value="">All Statuses</option>
                <option value="for-rent">For Rent</option>
                <option value="for-sale">For Sale</option>
              </select>
              
              <select
                className="w-full md:w-48 px-4 py-3 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-gold/50 focus:border-gold transition-all bg-white/50 backdrop-blur-sm"
                value={district}
                onChange={(e) => handleFilterChange('district', e.target.value)}
              >
                <option value="">All Districts</option>
                <option value="Kampala">Kampala</option>
                <option value="Wakiso">Wakiso</option>
              </select>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gold"></div>
          </div>
        ) : listings.length > 0 ? (
          viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {listings.map((listing: any) => (
                <ListingCard key={listing.code} listing={listing} />
              ))}
            </div>
          ) : (
            <MapView listings={listings} />
          )
        ) : (
          <div className="text-center py-20 bg-white/80 backdrop-blur-md rounded-xl border border-slate-100 shadow-sm">
            <Filter className="mx-auto h-12 w-12 text-slate-300 mb-4" />
            <h3 className="text-lg font-medium text-deep-navy mb-2">No properties found</h3>
            <p className="text-slate-500">Try adjusting your search filters to find what you're looking for.</p>
            <button
              onClick={() => setSearchParams(new URLSearchParams())}
              className="mt-6 text-gold hover:text-yellow-600 font-medium tracking-wider uppercase text-sm"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
