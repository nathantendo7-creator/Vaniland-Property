import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Phone, Mail, MapPin, Send } from 'lucide-react';

export default function Contact() {
  const [searchParams] = useSearchParams();
  const propertyCode = searchParams.get('property') || '';
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    propertyCode: propertyCode,
    goal: 'buy',
    budget: ''
  });
  
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    
    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      
      if (res.ok) {
        setStatus('success');
        setFormData({ name: '', email: '', phone: '', propertyCode: '', goal: 'buy', budget: '' });
      } else {
        setStatus('error');
      }
    } catch (err) {
      setStatus('error');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row relative">
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=2075&q=80"
          alt="Background"
          className="w-full h-full object-cover opacity-20"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-50/90 to-deep-navy/90" />
      </div>

      <div className="md:w-1/2 p-8 md:p-16 lg:p-24 flex flex-col justify-center relative z-10">
        <div className="max-w-md mx-auto w-full bg-white/80 backdrop-blur-xl p-8 rounded-2xl shadow-xl border border-white/50">
          <h1 className="text-4xl font-montserrat font-light text-deep-navy uppercase tracking-widest mb-4">Start Your Journey</h1>
          <p className="text-slate-500 mb-8">Whether you're investing, buying your first home, or figuring out your next move, we're here to help.</p>
          
          {status === 'success' ? (
            <div className="bg-green-50/80 backdrop-blur-sm text-green-800 p-6 rounded-xl border border-green-200">
              <h3 className="text-lg font-medium mb-2">Message Sent!</h3>
              <p>Thank you for reaching out. One of our consultants will be in touch shortly.</p>
              <button 
                onClick={() => setStatus('idle')}
                className="mt-4 text-green-700 font-medium hover:underline"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-8">
              <div>
                <label htmlFor="name" className="block text-[10px] font-medium text-slate-500 uppercase tracking-[0.2em] mb-2">Full Name *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-0 py-2 border-0 border-b border-slate-200 focus:ring-0 focus:border-gold transition-colors bg-transparent text-deep-navy font-light placeholder-slate-300"
                  placeholder="John Doe"
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label htmlFor="email" className="block text-[10px] font-medium text-slate-500 uppercase tracking-[0.2em] mb-2">Email Address *</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-0 py-2 border-0 border-b border-slate-200 focus:ring-0 focus:border-gold transition-colors bg-transparent text-deep-navy font-light placeholder-slate-300"
                    placeholder="john@example.com"
                  />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-[10px] font-medium text-slate-500 uppercase tracking-[0.2em] mb-2">Phone Number *</label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    required
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-0 py-2 border-0 border-b border-slate-200 focus:ring-0 focus:border-gold transition-colors bg-transparent text-deep-navy font-light placeholder-slate-300"
                    placeholder="+256..."
                  />
                </div>
              </div>

              <div>
                <label htmlFor="propertyCode" className="block text-[10px] font-medium text-slate-500 uppercase tracking-[0.2em] mb-2">Property Reference (Optional)</label>
                <input
                  type="text"
                  id="propertyCode"
                  name="propertyCode"
                  value={formData.propertyCode}
                  onChange={handleChange}
                  className="w-full px-0 py-2 border-0 border-b border-slate-200 focus:ring-0 focus:border-gold transition-colors bg-transparent text-deep-navy font-light placeholder-slate-300"
                  placeholder="e.g. 240181"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label htmlFor="goal" className="block text-[10px] font-medium text-slate-500 uppercase tracking-[0.2em] mb-2">Primary Goal</label>
                  <select
                    id="goal"
                    name="goal"
                    value={formData.goal}
                    onChange={handleChange}
                    className="w-full px-0 py-2 border-0 border-b border-slate-200 focus:ring-0 focus:border-gold transition-colors bg-transparent text-deep-navy font-light"
                  >
                    <option value="buy">Buy Property</option>
                    <option value="rent">Rent Property</option>
                    <option value="sell">Sell Property</option>
                    <option value="invest">Investment</option>
                    <option value="manage">Property Management</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="budget" className="block text-[10px] font-medium text-slate-500 uppercase tracking-[0.2em] mb-2">Investment Budget</label>
                  <select
                    id="budget"
                    name="budget"
                    value={formData.budget}
                    onChange={handleChange}
                    className="w-full px-0 py-2 border-0 border-b border-slate-200 focus:ring-0 focus:border-gold transition-colors bg-transparent text-deep-navy font-light"
                  >
                    <option value="">Select Budget...</option>
                    <option value="under-50m">Under 50M UGX</option>
                    <option value="50m-200m">50M - 200M UGX</option>
                    <option value="200m-500m">200M - 500M UGX</option>
                    <option value="500m+">500M+ UGX</option>
                  </select>
                </div>
              </div>

              {status === 'error' && (
                <p className="text-red-500 text-sm">There was an error submitting your request. Please try again.</p>
              )}

              <div className="pt-4">
                <button
                  type="submit"
                  disabled={status === 'submitting'}
                  className="w-full bg-deep-navy hover:bg-gold text-white py-4 rounded-sm uppercase tracking-[0.2em] text-xs font-medium transition-colors duration-300 flex justify-center items-center gap-2 disabled:opacity-70"
                >
                  {status === 'submitting' ? 'Sending...' : (
                    <>Start the Conversation <Send size={14} /></>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      <div className="md:w-1/2 p-8 md:p-16 lg:p-24 flex flex-col justify-center relative z-10">
        <div className="max-w-md mx-auto w-full bg-deep-navy/60 backdrop-blur-xl p-8 rounded-2xl shadow-xl border border-white/10 text-white">
          <h2 className="text-2xl font-montserrat font-light uppercase tracking-widest mb-12 text-gold">Direct Lines</h2>
          
          <div className="space-y-12">
            <div>
              <h3 className="text-sm font-montserrat uppercase tracking-widest text-slate-400 mb-6 border-b border-white/10 pb-2">Head Office</h3>
              <ul className="space-y-6">
                <li className="flex items-start gap-4">
                  <Phone className="text-gold mt-1" size={20} />
                  <div>
                    <p className="font-medium text-lg">+256-758-589258</p>
                    <p className="text-sm text-slate-400">Mon-Fri: 09:00 - 17:00</p>
                  </div>
                </li>
                <li className="flex items-start gap-4">
                  <Mail className="text-gold mt-1" size={20} />
                  <div>
                    <p className="font-medium text-lg">info@VanilandProperty.com</p>
                    <p className="text-sm text-slate-400">24/7 Support</p>
                  </div>
                </li>
                <li className="flex items-start gap-4">
                  <MapPin className="text-gold mt-1" size={20} />
                  <div>
                    <p className="font-medium text-lg">Kampala, Uganda</p>
                    <p className="text-sm text-slate-400">Main Branch</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
